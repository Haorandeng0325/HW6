package com.hw6.hangmanv5;

import androidx.fragment.app.Fragment;

public class BackgroundFragment extends Fragment {

  public BackgroundFragment( ) {
  }

  public String warning( ) {
    return "ONLY 1 LEFT!";
  }
}
