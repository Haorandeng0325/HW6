package com.hw6.exercise2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentB extends Fragment {
    private TextView tvShow;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_b, container, false);
        tvShow = view.findViewById(R.id.tv_light);
        return view;
    }

    public void show(int current){
        if(current % 3 == 1){
            tvShow.setText("Green Light");
            tvShow.setBackgroundResource(R.color.green);

        }else if(current % 3 == 2){
            tvShow.setText("Yellow Light");
            tvShow.setBackgroundResource(R.color.yellow);

        }else if(current % 3 == 0){
            tvShow.setText("Red Light");
            tvShow.setBackgroundResource(R.color.red);
        }
    }
}
