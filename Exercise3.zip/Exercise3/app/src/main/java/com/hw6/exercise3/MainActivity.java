package com.hw6.exercise3;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements FragmentA.OnButtonClickListener {
    private int current = 0;
    private FragmentB mFragmentB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mFragmentB = (FragmentB)getSupportFragmentManager().findFragmentById(R.id.fragment_b);

    }

    @Override
    public void onButtonClick() {
        current++;
        mFragmentB.show(current);
    }
}