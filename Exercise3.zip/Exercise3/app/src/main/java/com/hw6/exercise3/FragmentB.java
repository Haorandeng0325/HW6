package com.hw6.exercise3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentB extends Fragment {
    private TextView tvRed,tvYellow,tvGreen;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_b, container, false);
        tvRed = view.findViewById(R.id.tv_light_read);
        tvYellow = view.findViewById(R.id.tv_light_yellow);
        tvGreen = view.findViewById(R.id.tv_light_green);
        return view;
    }

    public void show(int current){
        if(current % 3 == 1){
            tvRed.setBackgroundResource(R.drawable.shape_white);
            tvYellow.setBackgroundResource(R.drawable.shape_white);
            tvGreen.setBackgroundResource(R.drawable.shape_green);
        }else if(current % 3 == 2){
            tvRed.setBackgroundResource(R.drawable.shape_white);
            tvYellow.setBackgroundResource(R.drawable.shape_yellow);
            tvGreen.setBackgroundResource(R.drawable.shape_white);
        }else if(current % 3 == 0){
            tvRed.setBackgroundResource(R.drawable.shape_red);
            tvYellow.setBackgroundResource(R.drawable.shape_white);
            tvGreen.setBackgroundResource(R.drawable.shape_white);
        }
    }
}
